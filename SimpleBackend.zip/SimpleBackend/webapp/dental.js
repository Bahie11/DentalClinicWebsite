function handleSignUp(event) {
    event.preventDefault(); // Prevents the form from submitting the traditional way

    // Collect form data
    const firstName = document.querySelector('input[name="firstName"]').value;
    const lastName = document.querySelector('input[name="lastName"]').value;
    const email = document.querySelector('input[name="email"]').value;
    const address = document.querySelector('input[name="address"]').value;
    const number = document.querySelector('input[name="number"]').value;
    const password = document.querySelector('input[name="password"]').value;
    const confirmPassword = document.querySelector('input[name="confirmPassword"]').value;

    // Check if password and confirmPassword match
    if (password !== confirmPassword) {
        alert("Passwords do not match. Please try again.");
        return false;
    }

    // Create a headers object
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    // Prepare the request body
    const raw = JSON.stringify({
        first_name: firstName,
        last_name: lastName,
        email: email,
        address: address,
        number: number,
        password: password
    });

    // Define the request options
    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    // Make the fetch request to the backend signup API
    fetch("http://localhost:5218/api/signup", requestOptions)
        .then((response) => response.json()) // Parse JSON response
        .then((result) => {

            alert("Signup successful!");
            // Redirect to login page after successful signup (optional)
            window.location.href = "login.html"; // Redirect to login page

        })
        .catch((error) => {
            console.error("Error:", error);
            alert("There was an error with the signup process. Please try again later.");
        });

    return false; // Prevent default form submission behavior
}


function handleLogin(event) {
    event.preventDefault(); // Prevents the form from submitting
    const email = document.querySelector('input[name="email"]').value;
    const password = document.querySelector('input[name="password"]').value;

    if (email && password) {
        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "email": email,
            "password": password
        });

        const requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        fetch("http://localhost:5218/api/login", requestOptions)
            .then((response) => {
                response.text()
                alert('Login successful! Welcome');
                window.location.href = "index.html";
            })
            .then((result) => console.log(result))
            .catch((error) => {
                console.error(error)
                alert('wrong email or password fields.');
            });
    } else {
        alert('Please fill out both the email and password fields.');

    }

    // Add additional actions here, such as validating credentials or redirecting
    return false; // Prevents default form submission behavior
}

function handleAppointment(event) {
    event.preventDefault(); // Prevents the form from submitting

    const name = document.querySelector('input[name="name"]').value;
    const email = document.querySelector('input[name="email"]').value;
    const number = document.querySelector('input[name="number"]').value;
    const date = document.querySelector('input[name="date"]').value;

    if (name && email && number && date) {
        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            "name": name,
            "email": email,
            "number": number,
            "date": date
        });

        const requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };

        fetch("http://localhost:5218/api/appointments", requestOptions) // Added "http://"
            .then((response) => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.text();
            })
            .then((result) => {
                console.log(result);
                alert(`Appointment successfully made! ${name}`);
            })
            .catch((error) => {
                console.error("Error:", error);
                alert("Failed to make the appointment. Please try again.");
            });
    } else {
        alert('Please fill out all the required fields.');
    }

    return false; // Prevents the default form submission behavior
}