


using System.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll",
        policy => policy.AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod());
});

var app = builder.Build();

// Use the "AllowAll" CORS policy
app.UseCors("AllowAll");



// Get the connection string from the configuration
string connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Define a GET endpoint to fetch data from the 'appointments' table
app.MapGet("/api/appointments", async () =>
{
    var appointments = new List<object>();

    using (var connection = new SqlConnection(connectionString))
    {
        await connection.OpenAsync();

        var query = "SELECT * FROM appointments";
        using (var command = new SqlCommand(query, connection))
        using (var reader = await command.ExecuteReaderAsync())
        {
            while (await reader.ReadAsync())
            {
                appointments.Add(new
                {
                    Id = reader["Id"],
                    Name = reader["Name"],
                    Date = reader["Date"]
                });
            }
        }
    }

    return Results.Ok(appointments);
});

app.MapPost("/api/appointments", async (HttpContext context) =>
{
    using var reader = new StreamReader(context.Request.Body);
    var requestBody = await reader.ReadToEndAsync();

    // Parse the JSON request body into a JsonDocument
    using var document = System.Text.Json.JsonDocument.Parse(requestBody);
    var root = document.RootElement;

    // Validate the required fields
    if (!root.TryGetProperty("name", out var nameElement) || 
        !root.TryGetProperty("email", out var emailElement) || 
        !root.TryGetProperty("date", out var dateElement))
    {
        return Results.BadRequest(new { Message = "Invalid input. 'name', 'email', and 'date' are required." });
    }

    string name = nameElement.GetString()!;
    string email = emailElement.GetString()!;
    string? number = root.TryGetProperty("number", out var numberElement) ? numberElement.GetString() : null;
    string date = dateElement.GetString()!;

    using (var connection = new SqlConnection(connectionString))
    {
        await connection.OpenAsync();

        var query = @"INSERT INTO appointments (name, email, number, date)
                      VALUES (@Name, @Email, @Number, @Date)";
        using (var command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@Name", name);
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Number", (object?)number ?? DBNull.Value);
            command.Parameters.AddWithValue("@Date", DateTime.Parse(date));

            await command.ExecuteNonQueryAsync();
        }
    }

    return Results.Ok(new { Message = "Appointment created successfully" });
});

app.MapPost("/api/signup", async (HttpContext context) =>
{
    using var reader = new StreamReader(context.Request.Body);
    var requestBody = await reader.ReadToEndAsync();

    using var document = System.Text.Json.JsonDocument.Parse(requestBody);
    var root = document.RootElement;

    // Validate required fields
    if (!root.TryGetProperty("first_name", out var firstNameElement) ||
        !root.TryGetProperty("last_name", out var lastNameElement) ||
        !root.TryGetProperty("email", out var emailElement) ||
        !root.TryGetProperty("address", out var addressElement) ||
        !root.TryGetProperty("number", out var numberElement) ||
        !root.TryGetProperty("password", out var passwordElement))
    {
        return Results.BadRequest(new { Message = "All fields are required." });
    }

    string firstName = firstNameElement.GetString()!;
    string lastName = lastNameElement.GetString()!;
    string email = emailElement.GetString()!;
    string address = addressElement.GetString()!;
    string number = numberElement.GetString()!;
    string password = passwordElement.GetString()!;

    using (var connection = new SqlConnection(connectionString))
    {
        await connection.OpenAsync();

        var query = @"INSERT INTO signin (first_name, last_name, email, address, number, password)
                      VALUES (@FirstName, @LastName, @Email, @Address, @Number, @Password)";
        using (var command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@FirstName", firstName);
            command.Parameters.AddWithValue("@LastName", lastName);
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("@Number", number);
            command.Parameters.AddWithValue("@Password", password);

            await command.ExecuteNonQueryAsync();
        }
    }

    return Results.Ok(new { Message = "Signup successful." });
});

app.MapPost("/api/login", async (HttpContext context) =>
{
    using var reader = new StreamReader(context.Request.Body);
    var requestBody = await reader.ReadToEndAsync();

    using var document = System.Text.Json.JsonDocument.Parse(requestBody);
    var root = document.RootElement;

    // Validate required fields
    if (!root.TryGetProperty("email", out var emailElement) ||
        !root.TryGetProperty("password", out var passwordElement))
    {
        return Results.BadRequest(new { Message = "Email and password are required." });
    }

    string email = emailElement.GetString()!;
    string password = passwordElement.GetString()!;

    using (var connection = new SqlConnection(connectionString))
    {
        await connection.OpenAsync();

        var query = @"SELECT COUNT(*) FROM signin WHERE email = @Email AND password = @Password";
        using (var command = new SqlCommand(query, connection))
        {
            command.Parameters.AddWithValue("@Email", email);
            command.Parameters.AddWithValue("@Password", password);

            var result = (int)await command.ExecuteScalarAsync();
            if (result > 0)
            {
                return Results.Ok(new { Message = "Login successful." });
            }
        }
    }

return Results.Json(new { Message = "Wrong email or password." }, statusCode: 401);

});




app.Run();
